1. compile:
```
source /opt/rksdk/envsetup.sh 
make
```

2. run
```
export LD_LIBRARY_PATH=/userdata/can2usb/:$LD_LIBRARY_PATH
./can
```
