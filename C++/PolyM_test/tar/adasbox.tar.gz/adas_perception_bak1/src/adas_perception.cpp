#include <sys/time.h>
#include "adas_perception_api.h"
#include "booaf_fsdk_api.h"
#include "CommonParam.h"
#include <vector>
#include <string>

#define DST_WIDTH 768
#define DST_HIGHT 384
#define START_TIMESTAMPE 1
//#define START_TIMESTAMPE (15471060032.71740746)


using namespace std;
using namespace cv;	
using namespace booaf;

std::vector<String> strPics_;
int image_number;
BOOAF_API my_api;

pthread_mutex_t mutex_npu = PTHREAD_MUTEX_INITIALIZER;
extern  bool first_frame_ad;

static int load_images(void)
{
	cout << "loading pictures!" << endl;
    string pattern = "../source/pics";
	strPics_.clear();
	cv::glob(pattern, strPics_, false);
	image_number = int(strPics_.size());
	cout << "Totally "<< image_number<<" images"  << endl;
	if (strPics_.empty()) {
		cout << "cannot find any pics!" << endl;
	}
	return 0;
}

void* bstAdas_perception_Handler(void* args)
{
    try
    {        
        adas_perception_init();        

        if(!adassysinfo.adasSourceCamera){
            LogInfo << "adas_perception load images." << std::endl;
            load_images();
        }
        
        RAW_FRAME_INFO camera_data;        

        int frame_id = 0;
        double begin_time = 0;
        std::string filename;
        double curr_time = START_TIMESTAMPE;
        double start_time = START_TIMESTAMPE;
        double end_time = START_TIMESTAMPE;
        cv::Mat src_cv_img,cv_img;
        ncnn::Mat ncnn_img;
        ADAS_PERCEPTION_INFOPack adasPerceptionData;
              
        while(1)
        {
            if(BE_QUIT)
            {
                std::cout <<"BE_QUIT quit bstAdas_perception_Handler..."<<std::endl;
                return NULL;
            }

            can_msg_input can_msg;
            memset(&can_msg,0,sizeof(can_msg));
            if(sysinfo.BE_MCU_RECEIVE_Enable){                
                if(MsgQueueReceiveMcuData.size() > 0){
                    RECEIVE_MCU_MSG receive_mcu_msg;
                    MsgQueueReceiveMcuData.get(receive_mcu_msg);
                    std::cout <<"speed status:" <<receive_mcu_msg.mcu_data.vechicle_speed_status<< " speed:"<<receive_mcu_msg.mcu_data.vechicle_speed<<std::endl;
                    std::cout <<"steer status:" <<receive_mcu_msg.mcu_data.steering_angle_status<< " steer:"<<receive_mcu_msg.mcu_data.steering_angle<<std::endl;
                    if(receive_mcu_msg.mcu_data.vechicle_speed_status){
                        can_msg.velocity = receive_mcu_msg.mcu_data.vechicle_speed;
                    }
                    if(receive_mcu_msg.mcu_data.steering_angle_status){
                        can_msg.steer = receive_mcu_msg.mcu_data.steering_angle;    //[degree, minus when turn left]
                    }
                }    
            }            

            start_time = my_api.GetTimestamp();            
            if(adassysinfo.adasSourceCamera){
                std::cout << "adas_perception get buff start." << std::endl;
                MsgQueueADASTODORAWFRAMEData.get(camera_data);
                std::cout << "adas_perception get buff end." << std::endl;
                cv_img = camera_data.frame.clone();
                cv::cvtColor(cv_img, src_cv_img, CV_RGB2BGR);
            }else{
                filename = strPics_[frame_id%image_number];
                //std::cout << "adas step_AA: " << my_api.GetTimestamp() - begin_time << " ms"  << std::endl;
                begin_time = my_api.GetTimestamp();
                //std::cout << "img path = " << filename << std::endl;
                src_cv_img = imread(filename);
                std::cout << "adas imread: " << my_api.GetTimestamp() - begin_time << " ms"  << std::endl;
                
                std::cout << "img = (" << src_cv_img.cols << "," << src_cv_img.rows << "," << src_cv_img.channels() << ")" << std::endl;           
                cv::cvtColor(src_cv_img, cv_img, CV_BGR2RGB);
                std::cout << "adas step1: " << my_api.GetTimestamp() - begin_time << " ms"  << std::endl;            
            }

            ncnn_img = ncnn::Mat(cv_img.cols, cv_img.rows, 3, (void *) cv_img.data, 1);            
            begin_time = my_api.GetTimestamp();
#if 0
            if(ncnn_img.empty()){
                cout << "ncnn_img enpty."<<endl;
            }else{
                cout << "ncnn_img.total:" << ncnn_img.total() << endl;
            }
#endif     
            /***********detetion*************/
            
            //frame_id++;
            AdasInfo adas_info;     //while local,global rect add problem
            cout<<"adas lock1."<< endl;
            pthread_mutex_lock(&mutex_npu);
            cout<<"adas lock2."<< endl;
            std::cout << "adas step3: " << my_api.GetTimestamp() - begin_time << " ms"  << std::endl;
            begin_time = my_api.GetTimestamp();
            //my_api.AD_Detect(adas_info, ncnn_img, frame_id);
            //my_api.AD_Detect(adas_info, ncnn_img, frame_id,frame_id == 0 ? 1 : 0);
	    int my_ret = my_api.AD_Detect(adas_info, ncnn_img, frame_id,first_frame_ad ? 1 : 0);
            if(first_frame_ad)
       		first_frame_ad=false;
            std::cout << "adas step4: " << my_api.GetTimestamp() - begin_time << " ms"  << std::endl;
            begin_time = my_api.GetTimestamp();
            cout<<"adas lock3."<< endl;
            pthread_mutex_unlock(&mutex_npu);
            cout<<"adas lock4."<< endl;

            //adas_result result;
            
            std::cout << "cv_img size: " << cv_img.cols << " " << cv_img.rows <<" "<<cv_img.channels()<<std::endl;                     
	    //adas_perception_process(curr_time,can_msg,adas_info, adasPerceptionData.adas_detecte_result);
	    adas_perception_process(src_cv_img, curr_time,can_msg,adas_info, adasPerceptionData.adas_detecte_result); 
            curr_time = curr_time + 0.05;
            std::cout << "adas step5: " << my_api.GetTimestamp() - begin_time << " ms"  << std::endl;
            begin_time = my_api.GetTimestamp();
            //std::cout << "result size: " << result.img.cols << " " << result.img.rows <<" "<<result.img.channels()<<std::endl;
            //adas_perception_dump(can_msg,adasPerceptionData.adas_detecte_result,src_cv_img);
	    adas_perception_dump(can_msg,adasPerceptionData.adas_detecte_result,src_cv_img);
            std::cout << "adas step6: " << my_api.GetTimestamp() - begin_time << " ms"  << std::endl;
            begin_time = my_api.GetTimestamp();            
            adasPerceptionData.frame = src_cv_img;
            MsgQueueAdasPerceptionData.put(adasPerceptionData);
                        
            frame_id++;
            std::cout << "adas step7: " << my_api.GetTimestamp() - begin_time << " ms"  << std::endl;
            end_time = my_api.GetTimestamp();
            std::cout << "adas fps : " << floor(1000/(end_time - start_time))  << std::endl;
        }
        std::cout  <<"quit bstAdas_perception_Handler..."<<std::endl;
    }
    catch(...)
    {
        //LogError << "bstAdas_perception_Handler failed";
        std::cout << "bstAdas_perception_Handler failed"<<std::endl;
    }
    std::cout <<"quit bstAdas_perception_Handler..."<<std::endl;
    adas_perception_exit();
    my_api.UnInit();
    pthread_exit(NULL);    
}

