
#ifndef ADAS_PERCEPTION_H
#define ADAS_PERCEPTION_H

extern void* bstAdas_perception_Handler(void* args);

#endif
