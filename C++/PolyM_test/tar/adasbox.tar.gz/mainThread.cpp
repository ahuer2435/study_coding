#include "CommonParam.h"
#include <vector>
#include <string>
#include <fstream>
//#include "DMSMainHandler.h"
#include "DMSCAMHandler.h"
#include "IMU_GPS_SRV.h"
#ifndef X86
#include "CAN_BUS.h"
#include "adas_perception.h"
#include "fcw_camera.h"
#endif
#include "HMI.h"
#include "json/json.h"
#include "log/easylogging++.h"
#include "interface/bst_dms_sdk_api.h"
#include "booaf_fsdk_api.h"
#include "AppInterface.h"
#include "hmi_interface.h"
#include "receive_from_mcu.h"
pthread_t DMSCAM_ID;
pthread_t DMSMAIN_ID;
pthread_t IMUGPS_ID;
pthread_t HMI_ID;
pthread_t CAN_ID;
pthread_t RECORD_RAW_VIDEO_ID;
pthread_t ADAS_PERCEPTION_ID;
pthread_t FCW_CAMERA_ID;
pthread_t CONFIG_PARAMETER_ID;
pthread_t CAMERA_ID;
pthread_t BST_DEC;
pthread_t MCU_RECEIVE_ID;
extern BOOAF_API my_api;
bool first_frame_ad=true;

#define APP_DEBUG 1

static int ReadConfigData(std::string& sPath,SysInfo& sysInfo,DMSInfo& dmsInfo,AdasSysInfo& adasSysInfo,DebugInfos& debugInfo, DeviceInfo& deviceInfo,CarInfo &carInfo, AdasCameraInfo &adasCameraInfo)
{
    std::cout << "a" <<std::endl;
    LogTrace << "Read Sys Config data..." << std::endl;
   std::ifstream ifs(sPath);
   if(!ifs.is_open())
   {
       LogError << "failed to open file " << sPath;
       return -1;
   }
   std::stringstream sbuffer;
   sbuffer << ifs.rdbuf();
   ifs.close();
   auto str = sbuffer.str();

   Json::Reader reader;
   Json::Value value;
   std::cout << "b" <<std::endl;
   if(reader.parse(str,value))
   {
       std::cout << "c" <<std::endl;
       sysInfo.BE_ADAS_Enable = value["SysInfo"]["BeAdasEnable"].asBool();
       std::cout << "d" <<std::endl;
       sysInfo.BE_DMS_Enable = value["SysInfo"]["BeDMSEnable"].asBool();
       sysInfo.BE_CAN_Enable = value["SysInfo"]["BeCAN"].asBool();
       sysInfo.BE_HMI_Enable = value["SysInfo"]["BeHMI"].asBool();
       sysInfo.BE_GPS_Enable = value["SysInfo"]["BeGPS"].asBool();
       sysInfo.BE_IMU_Enable = value["SysInfo"]["BeIMU"].asBool();
       sysInfo.BE_LCD_Enable = value["SysInfo"]["BeLCD"].asBool();
       sysInfo.BE_LED_Enable = value["SysInfo"]["BeLED"].asBool();
       sysInfo.BE_Save_Data = value["SysInfo"]["BeSaveData"].asBool();
       sysInfo.BE_SAVE_RAW_VIDEO_Enable = value["SysInfo"]["BeSaveRawVideo"].asBool();
       sysInfo.BE_ADAS_PERCEPTION_Enable = value["SysInfo"]["BeAdasPerception"].asBool();
       sysinfo.BE_FCW_CAMERA_Enable = value["SysInfo"]["BeFcwCameraEnable"].asBool();
       sysinfo.BE_CONFIG_PARAMTER_Enable = value["SysInfo"]["BeConfigParameterEnable"].asBool();
       sysinfo.BE_CAMERA_Enable = value["SysInfo"]["BeCameraEnable"].asBool();
       sysinfo.BE_MCU_RECEIVE_Enable = value["SysInfo"]["BeMcuReceiveEnable"].asBool();
       
 
       std::cout << "e" <<std::endl;
       sysInfo.sDataSavePath = value["SysInfo"]["DataSavePath"].asString();
       //std::cout << "1" <<std::endl;
       sysInfo.sDataReadPath = value["SysInfo"]["DataReadPath"].asString();
       //std::cout << "2" <<std::endl;
       sysInfo.Log_level  = value["SysInfo"]["LogLevel"].asInt();
       std::cout << "f" <<std::endl;
       dmsInfo.sCameraName = value["DMSPara"]["CameraName"].asString();
       dmsInfo.fDMSSpeedLastTime = value["DMSPara"]["DMSSpeedLastTime"].asFloat();
       dmsInfo.fDMSSpeedThresh = value["DMSPara"]["DMSSpeedThresh"].asFloat();
       dmsInfo.bDMSProcess = value["DMSPara"]["bDMSProcess"].asBool();
       dmsInfo.iDMSSampleInterval = value["DMSPara"]["DMSSampleInterval"].asInt();
       dmsInfo.bRecordOriFrame = value["DMSPara"]["bRecordOriFrame"].asBool();
       dmsInfo.bRecordProcessFrame = value["DMSPara"]["bRecordProcessedFrame"].asBool();
       dmsInfo.bFaceProcess = value["DMSPara"]["bFaceProcess"].asBool();
       dmsInfo.bDriverState = value["DMSPara"]["bUpdateDriveState"].asBool();
       dmsInfo.bDistractState = value["DMSPara"]["bUpdateDistractState"].asBool();
       dmsInfo.bLandmarkCover = value["DMSPara"]["bUpdateLandmarkCover"].asBool();
       dmsInfo.bBehaviourState = value["DMSPara"]["bUpdateBehaviourState"].asBool();
       dmsInfo.bFatigueState = value["DMSPara"]["bUpdateFatigueState"].asBool();
       dmsInfo.bIn3399 = value["DMSPara"]["bIn3399"].asBool();
       dmsInfo.runDMSWithoutSpeedThresh = value["DMSPara"]["runDMSWithoutSpeedThresh"].asBool();
       dmsInfo.iRecordFrameMax = value["DMSPara"]["FileRecordMaxFrame"].asInt();
       dmsInfo.sSavePath = value["DMSPara"]["FileStorePath"].asString();
#if  APP_DEBUG
        std::cout << "g" <<std::endl;
       adasSysInfo.sCameraName = value["AdasPara"]["CameraName"].asString();
       std::cout << "1" <<std::endl;
       adasSysInfo.fAdasSpeedLastTime = value["AdasPara"]["AdasSpeedLastTime"].asFloat();
       adasSysInfo.fAdasSpeedThresh = value["AdasPara"]["AdasSpeedThresh"].asFloat();
        std::cout << "2" <<std::endl;
       adasSysInfo.speedSource = value["AdasPara"]["SpeedSource"].asInt();
       std::cout << "3" <<std::endl;
       adasSysInfo.leftTurnSource = value["AdasPara"]["LeftTurnSource"].asInt();
       std::cout << "4" <<std::endl;
       adasSysInfo.rightTurnSource = value["AdasPara"]["RightTurnSource"].asInt();
       std::cout << "5" <<std::endl;
       adasSysInfo.brakeSource = value["AdasPara"]["BrakeSource"].asInt();
       std::cout << "6" <<std::endl;
       adasSysInfo.carBrand = value["AdasPara"]["CarBrand"].asString();
       std::cout << "7" <<std::endl;
       adasSysInfo.carModel = value["AdasPara"]["CarModel"].asString();
       std::cout << "h" <<std::endl;
       adasSysInfo.adasSourceCamera = value["AdasPara"]["AdasSourceCamera"].asBool();
       adassysinfo.camFormat = value["AdasPara"]["CameraFormat"].asInt();
       adassysinfo.camWidth = value["AdasPara"]["CameraWidth"].asInt();
       adassysinfo.camHeight = value["AdasPara"]["CameraHeight"].asInt();
#endif
       debugInfo.bDMSCAMReadData = value["DebugInfo"]["BeDMSCAMReadData"].asBool();
       debugInfo.bDMSMainReadData = value["DebugInfo"]["BeDMSMainReadData"].asBool();
       debugInfo.bIMU_GPSReadData = value["DebugInfo"]["BeIMUGPSReadData"].asBool();
        std::cout << "i" <<std::endl;
       hmipara.SmokingWarningInterval = value["HmiPara"]["SmokingInterval"].asInt();
       hmipara.PhoningWarningInterval = value["HmiPara"]["PhoningInterval"].asInt();
       hmipara.FatigueWarningInterval = value["HmiPara"]["FatigueInterval"].asInt();
       hmipara.WarningTimeInterval = value["HmiPara"]["WarningTimeInterval"].asFloat();
       fcwinfo.sCameraName = value["FcwInfo"]["CameraName"].asString();
        std::cout << "j" <<std::endl;
#if  APP_DEBUG
        deviceInfo.clientName = value["DeviceInfo"]["ClientName"].asString();
        std::cout << "1" <<std::endl;
        deviceInfo.managerName = value["DeviceInfo"]["ManageName"].asString();
        std::cout << "2" <<std::endl;
        deviceInfo.carId = value["DeviceInfo"]["CarId"].asString();
        std::cout << "3" <<std::endl;
        deviceInfo.deviceId = value["DeviceInfo"]["DeviceId"].asString();
        std::cout << "4" <<std::endl;
        deviceInfo.deviceModel = value["DeviceInfo"]["DeviceModel"].asString();
        std::cout << "5" <<std::endl;
        deviceInfo.deviceVersion = value["DeviceInfo"]["DeviceVersion"].asString();     
        std::cout << "6" <<std::endl;

        carInfo.carWidth = value["CarInfo"]["CarWidth"].asFloat();
        carInfo.frontWheelToCarHead = value["CarInfo"]["FrontWheelToCarHead"].asFloat();     
        carInfo.carYaw = value["CarInfo"]["CarYaw"].asFloat();     
        carInfo.carPitch = value["CarInfo"]["CarPitch"].asFloat();  
        #endif   
   }  
   return 0;
}

static int HardwareDetect(SysInfo)
{
    LogInfo << "hardware detect..." << std::endl;
    return 0;
}

int main(void)
{

   InitLogger();
   std::string sParaFilePath = "../AppData/TopParameter.json";
    
   if(ReadConfigData(sParaFilePath,sysinfo,dmsinfo,adassysinfo,debuginfo,deviceinfo,carinfo,adascamerainfo));
   //LOGFILE("AdasBox.log",sysinfo.Log_level);
   LogInfo << "AdasBox start!" << std::endl;
   sysinfo.print();
   debuginfo.print();
   dmsinfo.print();
   adassysinfo.print();
   PerfLogInfo << "try perflog";
   HardwareDetect(sysinfo);

#if 1

#ifndef X86

    if(sysinfo.BE_ADAS_PERCEPTION_Enable || sysinfo.BE_DMS_Enable){
        string model_path = "../ThirdParty/booaf_lib/data/";
        my_api.PrintFSDKVersion();
        int ret = my_api.Init(model_path.c_str(),booaf::BST_COMBINE,1); 
        //int ret = my_api.Init(model_path.c_str(),booaf::BST_ADAS,1); 
        std::cout << "ret = " << ret << std::endl;
    }

   if(sysinfo.BE_ADAS_PERCEPTION_Enable)
   {
#if 0
        string model_path = "../ThirdParty/booaf_lib/data/";
        std::cout << "adas_perception bofore load model." << std::endl;
        my_api.PrintFSDKVersion();
        int ret = my_api.Init(model_path.c_str(),booaf::BST_ADAS);
        std::cout << "ret = " << ret << std::endl;
        std::cout << "adas_perception loaded." << std::endl;
#endif
       int Ret = pthread_create(&ADAS_PERCEPTION_ID,NULL,bstAdas_perception_Handler,NULL);
       if(Ret)
       {
           LogInfo << "Failed to create adas perception thread!" << std::endl;
           return 1;
       }
       LogInfo <<"adas perception Thread created!" << std::endl;
   }

   if(sysinfo.BE_FCW_CAMERA_Enable)
   {
       int Ret = pthread_create(&FCW_CAMERA_ID,NULL,bstFcwCamera_Handler,NULL);
       if(Ret)
       {
           LogInfo << "Failed to create fcw camera thread!" << std::endl;
           return 1;
       }
       LogInfo <<"fcw camera Thread created!" << std::endl;
   }
#endif


   if(sysinfo.BE_IMU_Enable && sysinfo.BE_GPS_Enable)
   {
       IMU_GPS_HARDWARE_DATA imu_gps_hardware;
       int Ret = pthread_create(&IMUGPS_ID,NULL,bstIMU_GPS_SRV_Handler,&imu_gps_hardware);
       if(Ret)
       {
           LogInfo << "Failed to creat IMU_GPS thread!" << std::endl;
           return 1;
       }
       LogInfo <<"bstIMU_GPS_SRV_Handler Thread created!" << std::endl;
   }
   if(sysinfo.BE_DMS_Enable)
   {
      // if(!sysinfo.BE_CAMERA_Enable){
           DMSCamraHardware_data dmsCamHardware;
           int Ret = pthread_create(&DMSCAM_ID,NULL,bstDMS_CAMHandler,&dmsCamHardware);
           if(Ret)
           {
                LogInfo << "Failed to creat DMS_CAM thread!" << std::endl;
                return 1;
           }
           LogInfo <<"bstDMS_CAMHandler thread created..."<<std::endl;
       //}
        
       //Ret = pthread_create(&DMSMAIN_ID,NULL,bstDMSMAINHandler,(void*)0);
       //if(Ret)
       /*adding by zw */
       #if 1
        std::cout << "dms 1" <<std::endl;
        bstdms::BSTDMS_API *bstDMS=new bstdms::BSTDMS_API();
        //std::cout << "dms 2" <<std::endl;
        bstDMS->BstDmsInitlize("../ThirdParty/booaf_lib/data/");
        std::cout << "dms 3" <<std::endl;
       /*adding by zw */
       #endif

       //Ret = pthread_create(&DMSMAIN_ID,NULL,bstDMSMAINHandler,(void*)0);
       //if(Ret)
       if(0)
       {
           LogInfo << "Failed to create DMS_MAIN thread!" << std::endl;
           return 1;
       }
       //LogInfo <<"bstDMS_MainHandler thread created..."<<std::endl;
   }

#ifndef X86
   if(sysinfo.BE_CAN_Enable)
   {
       int Ret = pthread_create(&CAN_ID,NULL,bstCAN_BUS_Handler,NULL);
       if(Ret)
       {
           LogInfo << "Failed to creat CAN thread!" << std::endl;
           return 1;
       }
       LogInfo <<"CAN Thread created!" << std::endl;
   }
#endif

   if(sysinfo.BE_HMI_Enable)
   {
       /*
       int Ret = pthread_create(&HMI_ID,NULL,bstHMI_Handler,NULL);
       if(Ret)
       {
           LogInfo << "Failed to creat HMI thread!" << std::endl;
           return 1;
       }
       LogInfo <<"HMI Thread created!" << std::endl;
       */
   }

   if(sysinfo.BE_SAVE_RAW_VIDEO_Enable)
   {
       int Ret = pthread_create(&RECORD_RAW_VIDEO_ID,NULL,bstRecord_Video_Handler,NULL);
       if(Ret)
       {
           LogInfo << "Failed to creat RECORD_RAW_VIDEO thread!" << std::endl;
           return 1;
       }
       LogInfo <<"RECORD_RAW_VIDEO Thread created!" << std::endl;
   }

   if(sysinfo.BE_CAMERA_Enable)
   {
      int Ret = pthread_create(&CAMERA_ID,NULL,bstCamera_Handler,NULL);
      if(Ret)
      {
          LogInfo << "Failed to creat CAMERA thread!" << std::endl;
          return 1;
      }
      LogInfo <<"CAMERA Thread created!" << std::endl;
   }

   if(sysinfo.BE_MCU_RECEIVE_Enable)
   {
      int Ret = pthread_create(&MCU_RECEIVE_ID,NULL,bstMcu_Receive_Handler,NULL);
      if(Ret)
      {
          LogInfo << "Failed to mcu receive thread!" << std::endl;
          return 1;
      }
      LogInfo <<"mcu receive Thread created!" << std::endl;
   }

   if(0)
   {
      int Ret = pthread_create(&BST_DEC,NULL,bst_dec_Handler,NULL);
      if(Ret)
      {
          LogInfo << "Failed to creat BST_DEC thread!" << std::endl;
          return 1;
      }
      LogInfo <<"BST_DEC Thread created!" << std::endl;
   }
   
   HMI_dispaly();
   if(sysinfo.BE_CAMERA_Enable)
   { 
     pthread_join(CAMERA_ID,NULL);
   }
   if(sysinfo.BE_DMS_Enable){
       pthread_join(DMSCAM_ID,NULL);
   }
  
  if(sysinfo.BE_ADAS_PERCEPTION_Enable){
      pthread_join(ADAS_PERCEPTION_ID,NULL);
  }
   
   if(sysinfo.BE_HMI_Enable){
       pthread_join(HMI_ID,NULL);
   }
   
   if(sysinfo.BE_SAVE_RAW_VIDEO_Enable){
       pthread_join(RECORD_RAW_VIDEO_ID,NULL);
   }
   

#ifndef X86
    if(sysinfo.BE_CAN_Enable){
        pthread_join(CAN_ID,NULL);
    }
   
   if(sysinfo.BE_FCW_CAMERA_Enable){
       pthread_join(FCW_CAMERA_ID,NULL);
   }   
#endif
  
   if(sysinfo.BE_IMU_Enable && sysinfo.BE_GPS_Enable){
       pthread_join(IMUGPS_ID,NULL);
   }

   if(sysinfo.BE_MCU_RECEIVE_Enable)
   {
       pthread_join(MCU_RECEIVE_ID,NULL);
   }
   

#endif
#if 0
    if(sysinfo.BE_CONFIG_PARAMTER_Enable)
   {
       int Ret = pthread_create(&CONFIG_PARAMETER_ID,NULL,bstConfig_parameter_Handler,NULL);
       if(Ret)
       {
           LogInfo << "Failed to creat CONFIG_PARAMETER thread!" << std::endl;
           return 1;
       }
       LogInfo <<"CONFIG_PARAMETER Thread created!" << std::endl;
   }

    pthread_join(CONFIG_PARAMETER_ID,NULL);
#endif
   return 0;
}

