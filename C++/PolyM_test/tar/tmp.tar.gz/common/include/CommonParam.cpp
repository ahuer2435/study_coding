#include <pthread.h>
#include <queue>
#include <memory>
#include "CommonParam.h"

SysInfo sysinfo;
AdasSysInfo adassysinfo;
DMSInfo dmsinfo;
DebugInfos debuginfo;
HmiPara hmipara;
FCWInfo fcwinfo;
DeviceInfo deviceinfo;
CarInfo carinfo;
AdasCameraInfo adascamerainfo;
HAL_HANDLE *hal_handle;

//src::severity_channel_logger<severity_level,std::string> InfoLoger(keywords::channel = "LogSink");
//src::severity_channel_logger<severity_level,std::string> PerfLoger(keywords::channel = "PerfLogSink");

bool  BE_QUIT       =  false;
bool  bRecordDataTurn = false;
double   TimeStampDiffThreash = 3000.0;
// pthread_mutex_t mutex_DMSData = PTHREAD_MUTEX_INITIALIZER;
// pthread_mutex_t mutex_statData = PTHREAD_MUTEX_INITIALIZER;
// pthread_mutex_t  mutex_IMU_GPS = PTHREAD_MUTEX_INITIALIZER;
// pthread_cond_t   cond_DMSData = PTHREAD_COND_INITIALIZER;
// pthread_cond_t   cond_StatData = PTHREAD_COND_INITIALIZER;
// pthread_cond_t   cond_IMU_GPS_push = PTHREAD_COND_INITIALIZER;

// std::queue<std::shared_ptr<DMS_CAM_INFOPack>> g_queueDMSCameraData;
// std::queue<std::shared_ptr<DMS_STATE>> g_queueDMSStateData;
// std::queue<std::shared_ptr<IMU_GPS_SRV_Data>> g_queueIMU_GPSData;



//#ifdef USE_MSG_QUEUE_CLASS
bstMsgQueue<DMS_CAM_INFOPack>  MsgQueueDMSCameraData("CameraQueue");
bstMsgQueue<FaceToUiInfo>      MsgQueueDMSResultData("DMSStateQueue");
bstMsgQueue<DMS_STATE>         MsgQueueDMSStateData("DMSStateQueue");
bstMsgQueue<IMU_GPS_SRV_Data>  MsgQueueIMUGPSData("IMU_GPSQueue");
bstMsgQueue<DMS_HMI_INFO>      MsgQueueDMSHMIData("DMSHMIQueue");
bstMsgQueue<RAW_FRAME_INFO>    MsgQueueRAWFRAMEData("RAWFRAMEQueue", 16);
bstMsgQueue<RAW_FRAME_INFO>    MsgQueueDMSTODORAWFRAMEData("DMSTODORAWFRAMEQueue", 16);
bstMsgQueue<RAW_FRAME_INFO>    MsgQueueDMSFREERAWFRAMEData("DMSFREERAWFRAMEQueue", 16);
bstMsgQueue<RAW_FRAME_INFO>    MsgQueueADASTODORAWFRAMEData("FCWTODORAWFRAMEQueue", 16);
bstMsgQueue<RAW_FRAME_INFO>    MsgQueueADASFREERAWFRAMEData("FCWFREERAWFRAMEQueue", 16);
#ifndef X86
bstMsgQueue<CAN_MESSAGE>       MsgQueueCANData("CANQueue");
bstMsgQueue<FCW_CAM_INFOPack>  MsgQueueFCWCameraData("FCWCameraQueue");
bstMsgQueue<struct DmsProcData>  MsgQueueAdasCameraData("AdasCameraQueue", 4);
bstMsgQueue<ADAS_PERCEPTION_INFOPack>  MsgQueueAdasPerceptionData("AdasPerceptionQueue");
bstMsgQueue<RAW_FRAME_INFO>  MsgQueueAdasDMSData("AdasDMSQueue",4);
//bstMsgQueue<ADAS_DMS_INFOPack>  MsgQueueAdasDMSData("AdasDMSQueue",4);
bstMsgQueue<RECEIVE_MCU_MSG>  MsgQueueReceiveMcuData("ReceiveMcuQueue");

#endif
// #else
//     PolyM::Queue g_queueDMSCameraData;
//     PolyM::Queue g_queueDMSStateData;
//     PolyM::Queue g_queueIMUGPSData;
// #endif

