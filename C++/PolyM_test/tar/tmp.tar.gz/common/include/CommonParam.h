#ifndef COMMONPARAM_H
#define COMMONPARAM_H
#include <opencv2/opencv.hpp>
#include <pthread.h>
#include <climits>
#include <memory>
#include <deque>
#include <string>
#include <iostream>
#include "Msg.hpp"
#include "Queue.hpp"
#include "bstMsgQueue.h"
#include "bstLog.h"
#include "bstReadData.h"
#include "interface/bstFaceInterface.h"
#include "record_video.h"
#include "BSTHardware.h"
#include "BSTCamera.h"
#include "adas_perception_api.h"
#ifndef X86
#include "controlcan.h"
#include "uart_to_mcu.h"
#endif
#include <unistd.h>

#define DEBUG_WORKFLOW



extern bool  BE_QUIT;
extern bool  bRecordDataTurn;
extern double   TimeStampDiffThreash;
// extern pthread_mutex_t mutex_DMSData;
// extern pthread_mutex_t mutex_statData;
// extern pthread_mutex_t  mutex_IMU_GPS;
// extern pthread_cond_t   cond_DMSData;
// extern pthread_cond_t   cond_StatData;
// extern pthread_cond_t   cond_IMU_GPS_push;
//#define USE_MSG_QUEUE_CLASS
#define Param(para) #para << ":" << para << ","
typedef struct 
{
    bool BE_DMS_Enable;
    bool BE_ADAS_Enable;
    bool BE_IMU_Enable;
    bool BE_GPS_Enable;
    bool BE_LCD_Enable;
    bool BE_LED_Enable;
    bool BE_Save_Data;
    bool BE_CAN_Enable;
    bool BE_HMI_Enable;
    bool BE_SAVE_RAW_VIDEO_Enable;
    bool BE_ADAS_PERCEPTION_Enable;
    bool BE_FCW_CAMERA_Enable;
    bool BE_CONFIG_PARAMTER_Enable;
    bool BE_CAMERA_Enable;
    bool BE_MCU_RECEIVE_Enable;
    int  Log_level;
    std::string sDataSavePath;
    std::string sDataReadPath;
    
    
    void print()
    {
        LogInfo << Param(BE_DMS_Enable)
                << Param(BE_ADAS_Enable)
                << Param(BE_IMU_Enable)
                << Param(BE_GPS_Enable)
                << Param(BE_LCD_Enable)
                << Param(BE_LED_Enable)
                << Param(BE_Save_Data)
                << Param(BE_CAN_Enable)
                << Param(BE_HMI_Enable)
                << Param(BE_SAVE_RAW_VIDEO_Enable)
                << Param(BE_ADAS_PERCEPTION_Enable)
                << Param(BE_FCW_CAMERA_Enable)
                << Param(BE_CONFIG_PARAMTER_Enable)
                << Param(BE_CAMERA_Enable)
                << Param(BE_MCU_RECEIVE_Enable)
                << Param(Log_level)
                << Param(sDataSavePath)
                << Param(sDataReadPath);
    }
}SysInfo;

typedef struct 
{
    uint32_t  SmokingWarningInterval;
    uint32_t  PhoningWarningInterval;
    uint32_t  FatigueWarningInterval;
    float     WarningTimeInterval;

    void print()
    {
        LogInfo << Param(SmokingWarningInterval)
                << Param(PhoningWarningInterval)
                << Param(FatigueWarningInterval)
                << Param(WarningTimeInterval);
    }
}HmiPara;

typedef struct
{
    std::string sCameraName;
    float fDMSSpeedLastTime;
    float fDMSSpeedThresh;
    bool  bDMSProcess;
    int   iDMSSampleInterval;
    bool  bRecordOriFrame;
    bool  bRecordProcessFrame;

    bool  bFaceProcess;
    bool  bDriverState;
    bool  bDistractState;
    bool  bLandmarkCover;
    bool  bBehaviourState;
    bool  bFatigueState;
    bool  bIn3399;
    bool  runDMSWithoutSpeedThresh;
    int   iRecordFrameMax;

    std::string sSavePath;

    void print()
    {
        LogInfo << Param(sCameraName)
                << Param(fDMSSpeedLastTime)
                << Param(fDMSSpeedThresh)
                << Param(bDMSProcess)
                << Param(iDMSSampleInterval)
                << Param(bRecordOriFrame)
                << Param(bRecordProcessFrame)
                << Param(bFaceProcess)
                << Param(bDriverState)
                << Param(bDistractState)
                << Param(bLandmarkCover)
                << Param(bBehaviourState)
                << Param(bFatigueState)
                << Param(bIn3399)
                << Param(runDMSWithoutSpeedThresh)
                << Param(iRecordFrameMax)
                << Param(sSavePath);
    }
}DMSInfo;

typedef struct 
{
    bool  bDMSCAMReadData;
    bool  bDMSMainReadData;
    bool  bIMU_GPSReadData;

    void print()
    {
        LogDebug << Param(bDMSCAMReadData)
                 << Param(bDMSMainReadData)
                 << Param(bIMU_GPSReadData);
    }
}DebugInfos;

typedef struct 
{
    std::string sCameraName;
    float fAdasSpeedLastTime;
    float fAdasSpeedThresh;
    int speedSource;
    int leftTurnSource;
    int rightTurnSource;
    int brakeSource;
    std::string carBrand;
    std::string carModel;
    bool adasSourceCamera;
    int camFormat;
    int camWidth;
    int camHeight;
    void print()
    {
        LogInfo << Param(sCameraName)
                << Param(fAdasSpeedThresh)
                << Param(fAdasSpeedLastTime)
                << Param(speedSource)
                << Param(leftTurnSource)
                << Param(rightTurnSource)
                << Param(brakeSource)
                << Param(carBrand)
                << Param(adasSourceCamera)
                << Param(camFormat)
                << Param(camWidth)
                << Param(camHeight)
                << Param(carModel);
    }
}AdasSysInfo;

typedef struct 
{
    std::string clientName;
    std::string managerName;
    std::string carId;
    std::string deviceId;
    std::string deviceModel;
    std::string deviceVersion;
    void print()
    {
        LogInfo << Param(clientName)
                << Param(managerName)
                << Param(carId)
                << Param(deviceId)
                << Param(deviceModel)
                << Param(deviceVersion);
    }
}DeviceInfo;

typedef struct 
{
    float carWidth;
	float frontWheelToCarHead;
    float carYaw;
    float carPitch;
    void print()
    {
        LogInfo << Param(carWidth)
                << Param(frontWheelToCarHead)
                << Param(carYaw)
                << Param(carPitch);
    }
}CarInfo;

typedef struct 
{
    float CameraHeight;
	float CameraToRightEdge;
	float CameraToLeftEdge;
	float CameraToCarHead;

    void print()
    {
        LogInfo << Param(CameraHeight)
                << Param(CameraToRightEdge)
                << Param(CameraToLeftEdge)
                << Param(CameraToCarHead);
    }
}AdasCameraInfo;


//IMU_GPS_SRV input
typedef struct 
{
    int iIMUIdx;
    int iGPSIdx;
}IMU_GPS_HARDWARE_DATA;

typedef struct 
{
    int iCANIdx;    
}CAN_HARDWARE_DATA;


typedef struct
{
    char sCameraName[100];
} DMSCamraHardware_data;

//IMU_GPS_SRV_Data output
typedef struct 
{
    double dTimeStamp;
    float  fspeed;
    float  fRotAngle;
}IMU_GPS_SRV_Data;

#if 0
#define BYTE unsigned char
#define UINT unsigned int
typedef  struct  _VCI_CAN_OBJ{
	UINT	ID;
	UINT	TimeStamp;
	BYTE	TimeFlag;
	BYTE	SendType;
	BYTE	RemoteFlag;//是否是远程帧
	BYTE	ExternFlag;//是否是扩展帧
	BYTE	DataLen;
	BYTE	Data[8];
	BYTE	Reserved[3];
}VCI_CAN_OBJ;
#endif

#ifndef X86
typedef struct{
    double dTimeStamp;
    VCI_CAN_OBJ can_data;
}CAN_MESSAGE;

typedef struct{
    double dTimeStamp;
    RKREADDATA_t mcu_data;
}RECEIVE_MCU_MSG;

#endif

//DMS MAIN process Input
struct  DMS_CAM_INFOPack
{
    cv::Mat cvFrame;  
    double dTimeStamp;
    IMU_GPS_SRV_Data imu_gps_srv_Data;
    
    static int getDataSize()
    {
        return 48;
    }

    static void StoreData(std::ofstream& filestream,DMS_CAM_INFOPack& data)
    {
        filestream.write((char*)&data.dTimeStamp,sizeof(double));
        filestream.write((char*)&data.imu_gps_srv_Data,sizeof(IMU_GPS_SRV_Data));
        int matrow = data.cvFrame.rows;
        int matcol = data.cvFrame.cols;
        filestream.write((char*)&matrow,sizeof(int));
        filestream.write((char*)&matcol,sizeof(int));
        filestream.write((char*)data.cvFrame.data,sizeof(char)*matrow*matcol);
    }
    
    static void ReadData(std::ifstream& infilestream,DMS_CAM_INFOPack& data,int)
    {
        infilestream.read((char*)&data.dTimeStamp,sizeof(double));
        infilestream.read((char*)&data.imu_gps_srv_Data,sizeof(IMU_GPS_SRV_Data));
        int matrow = 0, matcol = 0;
        infilestream.read((char*)&matrow,sizeof(int));
        infilestream.read((char*)&matcol,sizeof(int));
        data.cvFrame.create(matrow,matcol,CV_8UC1);
        infilestream.read((char*)data.cvFrame.data,matcol*matrow*sizeof(char));
        LogDebug << "dTimeStamp:" << data.dTimeStamp << ",imuTimeStamp:" << data.imu_gps_srv_Data.dTimeStamp
                << ",Speed:" << data.imu_gps_srv_Data.fspeed << ",RotAngle:" << data.imu_gps_srv_Data.fRotAngle;
        LogDebug << "MatrixRow:" << matrow << ",MatrixCol:" << matcol;
        //for(int i = 0;i< matrow;i++)
        {
            LogDebug << (int)data.cvFrame.at<uchar>(0,0)<<","
                     << (int)data.cvFrame.at<uchar>(0,1)<<","
                     << (int)data.cvFrame.at<uchar>(0,2)<<","
                     << (int)data.cvFrame.at<uchar>(0,3)<<","
                     << (int)data.cvFrame.at<uchar>(1,0)<<","
                     << (int)data.cvFrame.at<uchar>(1,1)<<","
                     << (int)data.cvFrame.at<uchar>(1,2)<<","
                     << (int)data.cvFrame.at<uchar>(1,3)<<","
                     << (int)data.cvFrame.at<uchar>(2,0)<<","
                     << (int)data.cvFrame.at<uchar>(2,1)<<","
                     << (int)data.cvFrame.at<uchar>(2,2)<<","
                     << (int)data.cvFrame.at<uchar>(2,3)<<","
                     << (int)data.cvFrame.at<uchar>(3,0)<<","
                     << (int)data.cvFrame.at<uchar>(3,1)<<","
                     << (int)data.cvFrame.at<uchar>(3,2)<<","
                     << (int)data.cvFrame.at<uchar>(3,3)<<",";
        }
    }
};
//DMS MAIN Oint
typedef struct     
{
    int iFatigueLeve;
    bool bEyeClose;
    bool bMouseClose;
    double dTimeStamp;
} DMS_STATE;



typedef struct 
{
    cv::Mat      Camframe;
    IMU_GPS_SRV_Data  imu_gps_srv;
}DMS_CAM_INPara;


typedef struct
{
    //EDmsState   edmsState;
    EInDmsState   edmsState;
    CDmsSubItemState subItermState;
    FaceToUiInfo faceinfo;
    cv::Mat grayframe;
}DMS_HMI_INFO;

typedef struct
{
    int index;
    int width;
    int height;
    double fps;
    cv::Mat frame;
}RAW_FRAME_INFO;

typedef struct
{
    string cam_name;
    string format;
    bstMsgQueue<RAW_FRAME_INFO> *todo_msg_queue;
    bstMsgQueue<RAW_FRAME_INFO> *free_msg_queue;
} threadinfo_t;

typedef struct
{
    std::string sCameraName;
    
    void print()
    {
        LogInfo << Param(sCameraName);
        }
}FCWInfo;

struct  FCW_CAM_INFOPack
{
    int width;
    int height;
    double fps;
    cv::Mat frame;      
};

struct  ADAS_PERCEPTION_INFOPack
{
    int width;
    int height;
    double fps;
    cv::Mat frame;
    adas_result  adas_detecte_result;  
};

struct  ADAS_DMS_INFOPack
{
    int width;
    int height;
    double fps;
    cv::Mat frame;    
};


// extern std::queue<std::shared_ptr<DMS_STATE>> g_queueDMSStateData;

// extern std::queue<std::shared_ptr<DMS_CAM_INFOPack>> g_queueDMSCameraData;
// extern std::queue<std::shared_ptr<IMU_GPS_SRV_Data>> g_queueIMU_GPSData;// extern PolyM::Queue g_queueDMSCameraData;

// extern PolyM::Queue g_queueDMSStateData;
// extern PolyM::Queue g_queueIMUGPSData;

extern SysInfo sysinfo;
extern AdasSysInfo adassysinfo;
extern DebugInfos debuginfo;
extern DMSInfo  dmsinfo;
extern HmiPara  hmipara;
extern FCWInfo fcwinfo;
extern DeviceInfo deviceinfo;
extern HAL_HANDLE *hal_handle;
extern CarInfo carinfo;
extern AdasCameraInfo adascamerainfo;




//#ifdef USE_MSG_QUEUE_CLASS
extern bstMsgQueue<DMS_CAM_INFOPack>  MsgQueueDMSCameraData;
extern bstMsgQueue<FaceToUiInfo>      MsgQueueDMSResultData;
extern bstMsgQueue<DMS_STATE>         MsgQueueDMSStateData;
extern bstMsgQueue<IMU_GPS_SRV_Data>  MsgQueueIMUGPSData;
extern bstMsgQueue<DMS_HMI_INFO>      MsgQueueDMSHMIData;
extern bstMsgQueue<RAW_FRAME_INFO>    MsgQueueRAWFRAMEData;
extern bstMsgQueue<RAW_FRAME_INFO>    MsgQueueDMSTODORAWFRAMEData;
extern bstMsgQueue<RAW_FRAME_INFO>    MsgQueueDMSFREERAWFRAMEData;
extern bstMsgQueue<RAW_FRAME_INFO>    MsgQueueADASTODORAWFRAMEData;
extern bstMsgQueue<RAW_FRAME_INFO>    MsgQueueADASFREERAWFRAMEData;
#ifndef X86
extern bstMsgQueue<CAN_MESSAGE>       MsgQueueCANData;
extern bstMsgQueue<FCW_CAM_INFOPack>  MsgQueueFCWCameraData;
extern bstMsgQueue<struct DmsProcData>  MsgQueueAdasCameraData;
extern bstMsgQueue<ADAS_PERCEPTION_INFOPack>  MsgQueueAdasPerceptionData;
extern bstMsgQueue<RAW_FRAME_INFO>  MsgQueueAdasDMSData;
//extern bstMsgQueue<ADAS_DMS_INFOPack>  MsgQueueAdasDMSData;
extern bstMsgQueue<RECEIVE_MCU_MSG>  MsgQueueReceiveMcuData;

#endif
// #else
//     extern PolyM::Queue g_queueDMSCameraData;
//     extern PolyM::Queue g_queueDMSStateData;
//     extern PolyM::Queue g_queueIMUGPSData;
// #endif
#endif



