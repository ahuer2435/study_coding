#include "CommonParam.h"
#include "hmi_interface.h"

extern BOOAF_API my_api;

#define AudioFileNum 11
WarningState AdasState = NORMAL;
WarningState DmsState = NORMAL;
std::string cmd_prex = "aplay ";
std::string AudioFileName[AudioFileNum] = {"NULL","../source/no_distract.wav","../source/no_smoking.wav","../source/no_phoning.wav","../source/LDW.wav","../source/HMW.wav","../source/no_fatigue.wav","../source/no_driver.wav","../source/no_camera_covered.wav","../source/PCW.wav","../source/FCW.wav"};
double play_time,play_last_time;

static bool is_play = false;
static void play_video(const std::string &cmd)
{
    is_play = true;
	system(cmd.c_str());
    is_play = false;
}

static void plan_play(const WarningState &state)
{
    if(state != NORMAL){        
        if(!is_play){
            play_time = my_api.GetTimestamp();
            if((play_time-play_last_time)/1000.0 > hmipara.WarningTimeInterval){
                const std::string cmd = cmd_prex+AudioFileName[state]+" &";
                play_video(cmd);
                //LogInfo <<"no_phoning";
                //std::cout <<"no_phoning"<<std::endl;
                play_last_time = play_time;
            }                         
        }
    }
}

static WarningState adas_waring_status(bool is_adas_curr,ADAS_PERCEPTION_INFOPack &adasPerceptionData)
{
    WarningState state = NORMAL;
    if(is_adas_curr){
        if((adasPerceptionData.adas_detecte_result.warning.fcw==FCW_LEVEL_1) || (adasPerceptionData.adas_detecte_result.warning.fcw==FCW_LEVEL_2)){
            state = FCW;
            adasPerceptionData.adas_detecte_result.warning.fcw = 0;
        }else if((adasPerceptionData.adas_detecte_result.warning.pcw==PCW_LEVEL_1) || (adasPerceptionData.adas_detecte_result.warning.pcw==PCW_LEVEL_2)){
            state = PCW;
            adasPerceptionData.adas_detecte_result.warning.pcw = 0;
        }else if((adasPerceptionData.adas_detecte_result.warning.hmw==HMW_WARN)){
            state = HMW;
            adasPerceptionData.adas_detecte_result.warning.hmw = 0;
        }else if((adasPerceptionData.adas_detecte_result.warning.ldw==LDW_WARN_L) || (adasPerceptionData.adas_detecte_result.warning.ldw==LDW_WARN_R)){
            state = LDW;
            adasPerceptionData.adas_detecte_result.warning.ldw = 0;
        }
    }
    if(state != NORMAL){
        std::cout << "adas_waring_status: " << (int)state << std::endl;
    }    
    return state;
}

static WarningState dms_waring_status(bool is_dms_curr,DMS_HMI_INFO &dms_hmi_info)
{
    //std::cout <<(int)(dms_hmi_info.subItermState.behaviourState)<<std::endl;    
    WarningState state = NORMAL;
    if(is_dms_curr){
        if(dms_hmi_info.subItermState.cameraState == ECameraState::CAMERA_STATE_COVERED){
            state = NO_CAMERA_COVERED;
            //dms_hmi_info.subItermState.cameraState = 0;
        }else if(dms_hmi_info.subItermState.driverState == EDriverState::DRIVER_STATE_ABNORMAL){
            state = NO_DRIVER;
            //dms_hmi_info.subItermState.driverState = 0;
        }else if(dms_hmi_info.faceinfo.fatigue_level >=  TIRED_THRESHOLD){
            state = FATIGUE;
            //dms_hmi_info.faceinfo.fatigue_level = 0;
        }else if(dms_hmi_info.subItermState.behaviourState == EBehaviourState::BEHAVIOUR_STATE_PHONING){
            state = PHONING;
            //dms_hmi_info.subItermState.behaviourState = 0;
        }else if(dms_hmi_info.subItermState.behaviourState == EBehaviourState::BEHAVIOUR_STATE_SMOKING){
            state = SMOKING;
            //dms_hmi_info.subItermState.behaviourState = 0;
        }else if((dms_hmi_info.subItermState.distractState == EDistractState::DISTRACT_STATE_LEFT) || (dms_hmi_info.subItermState.distractState == EDistractState::DISTRACT_STATE_RIGHT) || (dms_hmi_info.subItermState.distractState == EDistractState::DISTRACT_STATE_DOWN) || (dms_hmi_info.subItermState.distractState == EDistractState::DISTRACT_STATE_OTHER) ){
            state = DISTRACT;
            //dms_hmi_info.subItermState.distractState = 0;
        }
    }
    std::cout << "dms_waring_status: " << (int)state << std::endl;
    return state;
}

static WarningState get_adasbox_status(bool is_adas_curr,bool is_dms_curr,ADAS_PERCEPTION_INFOPack &adasPerceptionData,DMS_HMI_INFO &dms_hmi_info)
{
    WarningState adasStatus,dmsStatus,adasboxStatus;
    adasStatus = adas_waring_status(is_adas_curr,adasPerceptionData);
    dmsStatus  = dms_waring_status(is_dms_curr,dms_hmi_info);
    adasboxStatus = (adasStatus > dmsStatus ? adasStatus:dmsStatus);
    std::cout << "get_adasbox_status: " << (int)adasboxStatus << std::endl;
    return adasboxStatus;
}


void HMI_dispaly()
{
    try
    {
        LogInfo <<"enter HMI_dispaly...";        
        cv::namedWindow("HMI",CV_WINDOW_NORMAL);        
        //cv::resizeWindow("HMI",1280,480);
        cv::resizeWindow("HMI",1360,768);
        cv::moveWindow("HMI",0,0);      
        
        DMS_HMI_INFO dms_hmi_info_last;
        ADAS_PERCEPTION_INFOPack adasPerceptionData_last;
        double begin_time = 0;
        bool is_adas_curr = false;
        bool is_dms_curr = false;
        double start_time,end_time;        

        bool first_dms_frame_valid = false;
        bool first_adas_frame_valid = false;

        RAW_FRAME_INFO adas_dms_result;

        //ADAS_DMS_INFOPack adas_dms_result;
        DMS_HMI_INFO dms_hmi_info;
        ADAS_PERCEPTION_INFOPack adasPerceptionData;
        cv::Mat tmp_dms_img,dms_img;
        cv::Mat adas_img;
        cv::Mat dst_adas_img;
        cv::Mat combine_img;


        while(1)
        {
            //ADAS_PERCEPTION_INFOPack adasPerceptionData;
            start_time = my_api.GetTimestamp();
            
                        //std::cout << "hmi 1" <<std::endl;           
            begin_time = my_api.GetTimestamp();
            
            if(sysinfo.BE_DMS_Enable){
                if(MsgQueueDMSHMIData.size() > 0){
                    is_dms_curr = true;
                    first_dms_frame_valid = true;
                    MsgQueueDMSHMIData.get(dms_hmi_info);
                    std::cout <<"dms_hmi_info " << dms_hmi_info.grayframe.rows<<" "<<dms_hmi_info.grayframe.cols<<" " << dms_hmi_info.grayframe.channels()<<std::endl;
                    dms_hmi_info_last.grayframe = dms_hmi_info.grayframe.clone();
                }else{
                    is_dms_curr = false;
                    dms_hmi_info = dms_hmi_info_last;
                }                
            }
            
            std::cout << "HMI_dispaly step_A: " << my_api.GetTimestamp() - begin_time << " ms"  << std::endl;
            begin_time = my_api.GetTimestamp();
            
            if(sysinfo.BE_DMS_Enable && first_dms_frame_valid){
                tmp_dms_img = dms_hmi_info.grayframe.clone();
                cv::Size rsize(640,480);
                cv::resize(tmp_dms_img, dms_img, rsize);
            }
            //std::cout << "HMI_dispaly step_B: " << my_api.GetTimestamp() - begin_time << " ms"  << std::endl;
            begin_time = my_api.GetTimestamp();

            if(sysinfo.BE_ADAS_PERCEPTION_Enable){
                if(MsgQueueAdasPerceptionData.size() > 0){
                    is_adas_curr = true;
                    first_adas_frame_valid = true;
                    MsgQueueAdasPerceptionData.get(adasPerceptionData);
                    std::cout <<"adasPerceptionData " << adasPerceptionData.frame.rows<<" "<<adasPerceptionData.frame.cols<<" " << adasPerceptionData.frame.channels()<<std::endl;
                    adasPerceptionData_last.frame = adasPerceptionData.frame.clone();                    
                }else{
                    is_adas_curr = false;
                    adasPerceptionData = adasPerceptionData_last;
                }                
            }
            std::cout << "HMI_dispaly step_C: " << my_api.GetTimestamp() - begin_time << " ms"  << std::endl;
            begin_time = my_api.GetTimestamp();            
            
            if(sysinfo.BE_ADAS_PERCEPTION_Enable && first_adas_frame_valid){
                adas_img = adasPerceptionData.frame.clone();            
            }
            //std::cout << "HMI_dispaly step_D: " << my_api.GetTimestamp() - begin_time << " ms"  << std::endl;
            begin_time = my_api.GetTimestamp();
            
            if(sysinfo.BE_ADAS_PERCEPTION_Enable && first_adas_frame_valid){                
                cv::Size rsize(640,480);
                cv::resize(adas_img, dst_adas_img, rsize);
            }
            std::cout << "HMI_dispaly step_E: " << my_api.GetTimestamp() - begin_time << " ms"  << std::endl;
            begin_time = my_api.GetTimestamp();
                        
            if(sysinfo.BE_ADAS_PERCEPTION_Enable && sysinfo.BE_DMS_Enable && first_adas_frame_valid && first_dms_frame_valid){
                //std::cout << "hmi 6" <<std::endl;
                hconcat(dst_adas_img,dms_img,combine_img);
                std::cout <<"dst_adas_img " << dst_adas_img.rows<<" "<<dst_adas_img.cols<<" " << dst_adas_img.channels()<<std::endl;
                std::cout <<"dms_img " << dms_img.rows<<" "<<dms_img.cols<<" " << dms_img.channels()<<std::endl;
                std::cout <<"combine_img " << combine_img.rows<<" "<<combine_img.cols<<" " << combine_img.channels()<<std::endl;
                adas_dms_result.width = combine_img.cols;
                adas_dms_result.height = combine_img.rows;
                adas_dms_result.frame = combine_img.clone();
                cv::imshow("HMI",combine_img); 
                //cv::moveWindow("HMI",0,0);
                cv::waitKey(1);
                std::cout << "HMI_dispaly step_F: " << my_api.GetTimestamp() - begin_time << " ms"  << std::endl;
                begin_time = my_api.GetTimestamp();
  
            }else  if(sysinfo.BE_DMS_Enable && first_dms_frame_valid){
                //std::cout << "hmi 6a" <<std::endl;
                adas_dms_result.width = dms_img.cols;
                adas_dms_result.height = dms_img.rows;
                adas_dms_result.frame = dms_img.clone();
                cv::imshow("HMI",dms_img);
                //cv::moveWindow("HMI",0,0);
                cv::waitKey(1);
            }else  if(sysinfo.BE_ADAS_PERCEPTION_Enable && first_adas_frame_valid){
                //std::cout << "hmi 6b" <<std::endl;
                adas_dms_result.width = dst_adas_img.cols;
                adas_dms_result.height = dst_adas_img.rows;
                adas_dms_result.frame = dst_adas_img.clone();
                cv::imshow("HMI",dst_adas_img);
                //cv::moveWindow("HMI",0,0);
                cv::waitKey(1);
            }
            //std::cout << "hmi 7" <<std::endl;
            //cv::waitKey(1);
            std::cout << "HMI_dispaly step_G: " << my_api.GetTimestamp() - begin_time << " ms"  << std::endl;
            begin_time = my_api.GetTimestamp();

            /**************adas warning******************/
            if(sysinfo.BE_ADAS_PERCEPTION_Enable || sysinfo.BE_DMS_Enable){               
               plan_play(get_adasbox_status(is_adas_curr,is_dms_curr,adasPerceptionData,dms_hmi_info));
            }
            std::cout << "HMI_dispaly step_G: " << my_api.GetTimestamp() - begin_time << " ms"  << std::endl;
            end_time = my_api.GetTimestamp();
            std::cout << "HMI_dispaly fps: " << floor(1000.0/(end_time-start_time)) << std::endl;
            adas_dms_result.fps = floor(1000.0/(end_time-start_time));
            std::cout << "adas_dms_result.width:" <<adas_dms_result.width<<std::endl;
            std::cout << "adas_dms_result.height:" <<adas_dms_result.height<<std::endl; 
            MsgQueueAdasDMSData.put(adas_dms_result);
        }
        LogInfo <<"quit HMI_dispaly...";
    }
    catch(...)
    {
        LogError << "HMI_dispaly failed";
    }     
}

