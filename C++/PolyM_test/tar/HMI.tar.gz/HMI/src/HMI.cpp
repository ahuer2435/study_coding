#include <sys/time.h>
#include "HMI.h"
#include "CommonParam.h"
//#define READ_IMU_GPS_DATA


static double get_currtime()
{
    struct timeval currentTime;
    gettimeofday(&currentTime,NULL);
    double dTimeStamp = currentTime.tv_sec + 0.000001 * currentTime.tv_usec;
    return dTimeStamp;
}

bool is_play = false;
void play_video(const std::string &cmd)
{
    is_play = true;
	system(cmd.c_str());
    is_play = false;
}

enum Driver_State
{
    NORMAL = 0,
	SMOKING,		
	PHONING,		
	FATIGUE,
};
uint8_t last_status = NORMAL;
uint32_t smoking_warning_count = 0;
uint32_t phoning_warning_count = 0; 
uint32_t fatigue_warning_count = 0; 


void* bstHMI_Handler(void* args)
{
    try
    {
        //bool bSaveModuleData = false; 
        //cv::namedWindow("HMI",CV_WINDOW_NORMAL);
        //cv::setWindowProperty("HMI",CV_WND_PROP_FULLSCREEN,CV_WINDOW_FULLSCREEN); 
        //std::string sFilename = "/media/usb0/dms/test.avi";       
        //cv::VideoWriter oriWriter;
        //oriWriter.open(sFilename,CV_FOURCC('M','J','P','G'),rawFrame.fps,cv::Size(rawFrame.width,rawFrame.height),true);

    
        LogInfo << "Thread bstHMI_Handler Start-----";

        LogInfo << hmipara.SmokingWarningInterval << hmipara.PhoningWarningInterval << hmipara.FatigueWarningInterval <<" " << hmipara.WarningTimeInterval;

        double phoning_curr_time = 0,phoning_last_time = 0;
        double smoking_curr_time = 0,smoking_last_time = 0;
        double fatigue_curr_time = 0,fatigue_last_time = 0;
        
        while(1)
        {
            if(BE_QUIT)
            {
                LogInfo <<"BE_QUIT quit bstHMI_Handler...";
                return NULL;
            }
            DMS_HMI_INFO dms_hmi_info;
            std::cout << "hmi 1" <<std::endl;
            FCW_CAM_INFOPack fcwframe;
            std::cout << "hmi 2" <<std::endl;
            ADAS_PERCEPTION_INFOPack adasPerceptionData;

            //LogInfo <<"before get hmi data";
            MsgQueueDMSHMIData.get(dms_hmi_info);
            std::cout << "hmi 3" <<std::endl;
            
            //MsgQueueAdasPerceptionData.get(adasPerceptionData);

            //MsgQueueFCWCameraData.get(fcwframe);
            std::cout << "hmi 4" <<std::endl;
            //LogInfo << "geted hmi data";
            cv::Mat combine_img,fcw_grayframe,adas_grayframe;
            std::cout << "hmi 5" <<std::endl;
            std::cout << dms_hmi_info.grayframe.rows <<" "<<dms_hmi_info.grayframe.cols <<" "<<dms_hmi_info.grayframe.channels() <<std::endl;
            //std::cout << fcwframe.frame.rows <<" "<<fcwframe.frame.cols <<" "<<fcwframe.frame.channels() <<std::endl;
            //std::cout << adasPerceptionData.frame.rows <<" "<<adasPerceptionData.frame.cols <<" "<<adasPerceptionData.frame.channels() <<std::endl;

            #if 0
            if(adasPerceptionData.frame.channels() == 3)
            {
                cv::cvtColor(adasPerceptionData.frame, adas_grayframe, cv::COLOR_BGR2GRAY);
            }else{
                adas_grayframe = adasPerceptionData.frame;
            }
            
            std::cout << "sycn ..." <<std::endl;
            std::cout << dms_hmi_info.grayframe.rows <<" "<<dms_hmi_info.grayframe.cols <<" "<<dms_hmi_info.grayframe.channels() <<std::endl;
            //std::cout << fcw_grayframe.rows <<" "<<fcw_grayframe.cols <<" "<<fcw_grayframe.channels() <<std::endl;
            std::cout << adas_grayframe.rows <<" "<<adas_grayframe.cols <<" "<<adas_grayframe.channels() <<std::endl;

            hconcat(dms_hmi_info.grayframe,adas_grayframe,combine_img);
            //vconcat(dms_hmi_info.grayframe,fcw_grayframe,combine_img);
            std::cout << "hmi 6" <<std::endl;
            cv::imshow("HMI",combine_img);
            #endif
            
            cv::imshow("HMI",dms_hmi_info.grayframe);
            std::cout << "hmi 7" <<std::endl;
            //cv::waitKey(2);
            std::cout << "hmi 8" <<std::endl;
            if(dms_hmi_info.subItermState.behaviourState == EBehaviourState::BEHAVIOUR_STATE_PHONING){
                
                phoning_curr_time = get_currtime();
                if(!is_play){
                    if(phoning_curr_time-phoning_last_time > hmipara.WarningTimeInterval){
                        play_video("aplay ../source/no_phoning.wav &");
                        LogInfo <<"no_phoning";
                        //std::cout <<"no_phoning"<<std::endl;
                        phoning_last_time = phoning_curr_time;
                    }                    
                }
            } else if(dms_hmi_info.subItermState.behaviourState == EBehaviourState::BEHAVIOUR_STATE_SMOKING){

                smoking_curr_time = get_currtime();
                if(!is_play){                    
                    if(smoking_curr_time-smoking_last_time > hmipara.WarningTimeInterval){
                        play_video("aplay ../source/no_smoking.wav &");
                        LogInfo <<"no_smoking";
                        //std::cout <<"no_smoking"<<std::endl;
                        smoking_last_time = smoking_curr_time;
                    }                    
                }

            } else if(dms_hmi_info.subItermState.fatigueState != EFatigueState::FATIGUE_STATE_CLEAR){

                fatigue_curr_time = get_currtime();
                //LogInfo <<"no_fatigue " << fatigue_curr_time << " " << fatigue_last_time << " " << fatigue_curr_time-fatigue_last_time << " "<< hmipara.WarningTimeInterval;
                if(!is_play){
                    if(fatigue_curr_time-fatigue_last_time > hmipara.WarningTimeInterval){
                        play_video("aplay ../source/no_fatigue.wav &");
                        LogInfo <<"no_fatigue warning";
                        //LogInfo <<"no_fatigue " << fatigue_curr_time << " " << fatigue_last_time << " " << fatigue_curr_time-fatigue_last_time << " "<< hmipara.WarningTimeInterval;                        
                        //std::cout <<"no_fatigue"<<std::endl;
                        fatigue_last_time = fatigue_curr_time;
                    }                                        
                }                
            }                
        }
        LogInfo <<"quit bstHMI_Handler...";
    }
    catch(...)
    {
        LogError << "bstHMI_Handler failed";
    }
    pthread_exit(NULL);    
}