
#ifndef HMI_H
#define HMI_H

extern void* bstHMI_Handler(void* args);

#endif
